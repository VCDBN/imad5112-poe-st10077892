package com.example.imad5112st10077892poepartthree

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    val numbersArray = IntArray(10)
    var currentIndex = 0

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)


            val statisticsfunctions = findViewById<TextView>(R.id.tvStats)
            val enternumber = findViewById<TextView>(R.id.tvEnter)
            val number = findViewById<EditText>(R.id.etNumber)
            val add = findViewById<Button>(R.id.btnAdd)
            val numbersstoredinmemory = findViewById<TextView>(R.id.tvStored)
            val output1 = findViewById<TextView>(R.id.tvOutput1)
            val clear = findViewById<Button>(R.id.btnClear)
            val calculateaverage = findViewById<Button>(R.id.btnCalculateAverage)
            val findminandmax = findViewById<Button>(R.id.btnFindMinAndMax)
            val output2 = findViewById<TextView>(R.id.tvOutput2)


            add.setOnClickListener {
                if (currentIndex < 10) {
                    val enteredNumber = number.text.toString().toInt()
                    numbersArray[currentIndex] = enteredNumber
                    currentIndex++
                    updateNumbersStoredDisplay()
                    number.text.clear()
                } else {

                }
            }

            clear.setOnClickListener {
                currentIndex = 0

                numbersArray.fill(0)
                updateNumbersStoredDisplay()
            }

            calculateaverage.setOnClickListener {
                if (currentIndex > 0) {
                    val enteredNumbers = numbersArray.slice(0 until currentIndex)
                    val sum = enteredNumbers.sum()
                    val average = sum.toDouble() / currentIndex.toDouble()
                    output2.text = "Average: $average"
                } else {
                    output2.text = "No numbers entered yet."
                }
            }

            findminandmax.setOnClickListener {
                if (currentIndex > 0) {
                    val enteredNumbers = numbersArray.slice(0 until currentIndex)
                    val min = enteredNumbers.minOrNull()
                    val max = enteredNumbers.maxOrNull()
                    output2.text = "Min: $min, Max: $max"
                } else {
                    output2.text = "No numbers entered yet."
                }
            }

        }

    private fun updateNumbersStoredDisplay() {
        val numbersString = numbersArray.slice(0 until currentIndex).joinToString(", ")
        findViewById<TextView>(R.id.tvStored).text = "Numbers stored in memory: $numbersString"
    }


    }

